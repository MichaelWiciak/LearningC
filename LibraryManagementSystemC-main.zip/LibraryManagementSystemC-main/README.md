# LibraryManagementSystemC
Basic library management system. First implementations of dynamic memory allocation and make files.
