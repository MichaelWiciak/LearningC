# TicTacToeGame
Tic Tac Toe game implemented in C. Works on more dimensions than the traditional game.

Implemented the checking if a player has won the game in two ways: one checks every tile and the other only checks the recent player move.
This is used find out the actual difference in function calls between optimised and unoptimised code.
