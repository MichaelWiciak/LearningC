# WaterCompanyManagementSystem
Very basic management system I implemented while learning C
